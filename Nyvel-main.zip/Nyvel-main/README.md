# Nyvel
Offcial website for Nyvel company and co. 

# Commits
I should be the only one making commits becuase frankly, you can't code, and that is a massive skill issue.

# Product
I need some mock product name and specs so list them here
<li>final consumer products will use an N denominator with a dash to show generation name ex. N-1 (consumer product gen 1), then after will show the type and since we are in battery tech we will use cell denoms after so for a gen one consumer 21700 type cell it will be "N-1 21700" </li>
<li>for experimental we will use a Ë denom plus the generation that is being tweaked and then the iteration of the tweak so Ë-2-3</li>

# Website visiblity and hosting
We should use railway, because I have a bias for their futuristic ui.

# Domain 
Could we use magsaved.store? That would work for testing and showing progress easily to others. (mostly cuz I have ego issues and want praise)
