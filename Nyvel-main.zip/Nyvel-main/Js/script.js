//no js? No way, maybe I should write an malware auto installer.
